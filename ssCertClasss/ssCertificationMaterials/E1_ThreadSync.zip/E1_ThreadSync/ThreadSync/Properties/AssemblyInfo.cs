﻿using System.Reflection;

[assembly: AssemblyTitle("ThreadSync")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ThreadSync")]
[assembly: AssemblyCopyright("Copyright ©  2015")]
[assembly: AssemblyVersion("1.0.0.*")]

